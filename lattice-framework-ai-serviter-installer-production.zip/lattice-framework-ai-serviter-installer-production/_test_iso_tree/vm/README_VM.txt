AI Serviter VM Notes
--------------------
This OVF is a hardware profile scaffold. To create a real importable appliance:
1. Install Ubuntu Server/Desktop in a VM.
2. Copy this ISO/package into the VM.
3. Install with scripts/install_unix.sh.
4. Export the VM as OVF/OVA from your hypervisor.
5. Attach the real disk reference to vm_config.ovf if packaging manually.
