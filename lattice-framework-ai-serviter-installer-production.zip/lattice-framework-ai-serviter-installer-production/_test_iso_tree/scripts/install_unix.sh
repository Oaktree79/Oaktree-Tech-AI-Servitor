#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../app/python"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -U pip
python -m pip install -e ".[dev]"
echo "Installed. Run: serviter-service --root . --mode api"
