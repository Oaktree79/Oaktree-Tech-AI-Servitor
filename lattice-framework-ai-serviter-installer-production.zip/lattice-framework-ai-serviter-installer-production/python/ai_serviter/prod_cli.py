from __future__ import annotations

import argparse
import json

from .distributed_worker import DistributedWorker
from .integration_harness import IntegrationHarness
from .deployment_validator import DeploymentValidator
from .security_hardening import SecurityHardeningChecker
from .postgres_config import ProductionDatabaseConfig
from .llm_validation import LLMConfigValidator
from .user_management import UserManagement
from .database import ServiterDatabase
from .isolation_manager import IsolationManager
from .k8s_tester import KubernetesDeploymentTester
from .llm_runtime import LLMRuntime
from .network_policy import NetworkPolicy
from .oidc_auth import OIDCAuthConfig
from .pr_automation import PullRequestAutomation
from .runtime import ServiterRuntime
from .secrets_manager import SecretsManager


def main():
    parser = argparse.ArgumentParser(description="AI Serviter production module CLI")
    parser.add_argument("--root", default=".")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("llm-status")
    sub.add_parser("isolation-status")
    sub.add_parser("worker-run-once")
    sub.add_parser("workers")
    sub.add_parser("metrics")
    sub.add_parser("oidc-status")
    sub.add_parser("integration-smoke")
    sub.add_parser("deployment-files-check")
    sub.add_parser("security-hardening-check")
    sub.add_parser("postgres-status")
    sub.add_parser("llm-validate")
    sub.add_parser("users")

    net = sub.add_parser("network-check")
    net.add_argument("url")

    secret_get = sub.add_parser("secret-get")
    secret_get.add_argument("name")

    gh = sub.add_parser("github-pr")
    gh.add_argument("--title", required=True)
    gh.add_argument("--body", default="")

    gl = sub.add_parser("gitlab-mr")
    gl.add_argument("--title", required=True)
    gl.add_argument("--description", default="")

    k8s = sub.add_parser("k8s-validate")
    k8s.add_argument("path")

    args = parser.parse_args()

    if args.command == "llm-status":
        print(json.dumps(LLMRuntime().status(), indent=2))
    elif args.command == "isolation-status":
        print(json.dumps(IsolationManager(args.root).status(), indent=2))
    elif args.command == "worker-run-once":
        print(json.dumps(DistributedWorker(args.root).run_once(), indent=2))
    elif args.command == "workers":
        print(json.dumps(DistributedWorker(args.root).workers(), indent=2))
    elif args.command == "metrics":
        runtime = ServiterRuntime(args.root)
        print(runtime.observability.prometheus())
    elif args.command == "oidc-status":
        print(json.dumps(OIDCAuthConfig().ready(), indent=2))
    elif args.command == "integration-smoke":
        print(json.dumps(IntegrationHarness(args.root).run_smoke(), indent=2))
    elif args.command == "deployment-files-check":
        print(json.dumps(DeploymentValidator(args.root).validate_files_present(), indent=2))
    elif args.command == "security-hardening-check":
        print(json.dumps(SecurityHardeningChecker(args.root).check(), indent=2))
    elif args.command == "postgres-status":
        print(json.dumps(ProductionDatabaseConfig().validate(), indent=2))
    elif args.command == "llm-validate":
        print(json.dumps(LLMConfigValidator().validate_status(), indent=2))
    elif args.command == "users":
        print(json.dumps(UserManagement(ServiterDatabase(f"{args.root}/.serviter/serviter.db")).list_users(), indent=2))
    elif args.command == "network-check":
        print(json.dumps(NetworkPolicy().check_url(args.url), indent=2))
    elif args.command == "secret-get":
        value = SecretsManager().get(args.name)
        print(json.dumps({"name": args.name, "present": value is not None}, indent=2))
    elif args.command == "github-pr":
        print(json.dumps(PullRequestAutomation(args.root).create_github_pr(args.title, args.body), indent=2))
    elif args.command == "gitlab-mr":
        print(json.dumps(PullRequestAutomation(args.root).create_gitlab_mr(args.title, args.description), indent=2))
    elif args.command == "k8s-validate":
        print(json.dumps(KubernetesDeploymentTester(args.root).validate_yaml(args.path), indent=2))


if __name__ == "__main__":
    main()
