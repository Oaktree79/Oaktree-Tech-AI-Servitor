from __future__ import annotations

from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os


class DashboardServer:
    def __init__(self, static_dir: str | Path, host: str = "127.0.0.1", port: int = 8787):
        self.static_dir = Path(static_dir).resolve()
        self.host = host
        self.port = port

    def serve(self):
        os.chdir(self.static_dir)
        server = ThreadingHTTPServer((self.host, self.port), SimpleHTTPRequestHandler)
        print(f"AI Serviter dashboard listening on http://{self.host}:{self.port}")
        server.serve_forever()
