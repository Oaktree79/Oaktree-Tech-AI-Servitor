from __future__ import annotations

from pathlib import Path
from typing import Dict
import json
import tempfile

from .agent_loop import ClosedLoopCodingAgent
from .llm_runtime import LLMRuntime
from .structured_patch import StructuredPatchParser


class RealLLMWorkflowHarness:
    """
    Validates whether the configured LLM can produce structured patch JSON.

    Safe by default:
    - does not auto-apply unless explicitly requested
    - runs inside a temporary fixture project
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()

    def validate_patch_generation(self, auto_apply: bool = False) -> Dict:
        runtime = LLMRuntime()
        status = runtime.status()

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            (tmp_path / "hello.py").write_text("def hello():\n    return 'hello'\n", encoding="utf-8")
            agent = ClosedLoopCodingAgent(tmp_path, llm=runtime.provider, max_attempts=1)
            result = agent.run(
                "Change hello.py so hello() returns 'hello world'. Return a structured JSON patch.",
                context={"file": "hello.py"},
                auto_apply=auto_apply,
            )
            return {
                "llm_status": status,
                "auto_apply": auto_apply,
                "result": result,
            }

    def validate_parser_contract(self) -> Dict:
        sample = {
            "summary": "Update hello function",
            "edits": [{"path": "hello.py", "after": "def hello():\n    return 'hello world'\n"}],
            "test_command": ["python", "-m", "compileall", "-q", "."],
        }
        patch = StructuredPatchParser().parse(json.dumps(sample))
        return {"ok": patch.edits[0].path == "hello.py", "edit_count": len(patch.edits)}
