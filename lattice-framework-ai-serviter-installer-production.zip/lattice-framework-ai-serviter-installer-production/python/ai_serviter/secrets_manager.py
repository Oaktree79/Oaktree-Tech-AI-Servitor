from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional
import base64
import json
import os


class SecretsManager:
    """
    Simple secrets abstraction.

    Backends:
    - env: read from environment variables
    - file: local base64-encoded JSON file for development only

    Production should replace file backend with Vault, AWS Secrets Manager, Azure Key Vault, or GCP Secret Manager.
    """

    def __init__(self, backend: str = "env", path: str | Path = ".serviter/secrets.json"):
        self.backend = backend
        self.path = Path(path)

    def get(self, name: str, default: Optional[str] = None) -> Optional[str]:
        if self.backend == "env":
            return os.getenv(name, default)
        data = self._load_file()
        return data.get(name, default)

    def set_dev_secret(self, name: str, value: str):
        if self.backend != "file":
            raise RuntimeError("set_dev_secret is only available for file backend")
        data = self._load_file()
        data[name] = value
        self.path.parent.mkdir(parents=True, exist_ok=True)
        encoded = base64.b64encode(json.dumps(data).encode()).decode()
        self.path.write_text(encoded, encoding="utf-8")

    def _load_file(self) -> Dict[str, str]:
        if not self.path.exists():
            return {}
        raw = self.path.read_text(encoding="utf-8")
        try:
            return json.loads(base64.b64decode(raw.encode()).decode())
        except Exception:
            return {}
